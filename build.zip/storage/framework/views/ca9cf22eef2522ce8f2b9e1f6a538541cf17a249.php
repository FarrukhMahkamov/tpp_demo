# Introduction

<?php echo $description; ?>


<?php echo $introText; ?>


> Base URL

```yaml
<?php echo $baseUrl; ?>

```<?php /**PATH C:\xampp\htdocs\tpp_demo\vendor\knuckleswtf\scribe\src/../resources/views//markdown/intro.blade.php ENDPATH**/ ?>